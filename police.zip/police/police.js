
const button = document.querySelector("button")
button.addEventListener("click", showSalaryCalculation)

function showSalaryCalculation() {
    const span1 = document.getElementById("salaryCalculation")
    span1.style.display = "initial"
    calculatePay()
}

let twoYearsXP = document.getElementById("oneT")
console.log(twoYearsXP)
let trainingXP = document.getElementById("w/B")
let pilotLicense = document.getElementById("payB")
let scubaDiving = document.getElementById("All")
let baseSalary = 50000
let bs1tBonuses = 50000
let salaryWithBonuses = 50000
let salaryOT = 50000
let totalYearlySalary = 50000
let monthlyWithoutPB = 4167
let monthlyWithPB = 4167
const span2 = document.getElementById("span2")
const span3 = document.getElementById("span3")
const span4 = document.getElementById("span4")
const span5 = document.getElementById("span5")
const span6 = document.getElementById("span6")
const span7 = document.getElementById("span7")

function calculatePay() {
    console.log("calculatePay ran")
    if (twoYearsXP.checked === true) {
        console.log("first if")
        bs1tBonuses += 2000
        salaryWithBonuses += 2000
        totalYearlySalary += 2000
    }
    if (trainingXP.checked === true) {
        console.log("second if")

        salaryOT += 1200
        baseSalary += 1200
        monthlyWithPB += 100
        totalYearlySalary += 1200
    }
    if (pilotLicense.checked === true) {
        console.log("fthird if")

        bs1tBonuses += 500
        salaryOT += 300
        totalYearlySalary += 800
    }
    if (scubaDiving.checked === true) {
        console.log("fourth if")

        salaryWithBonuses += 250
        totalYearlySalary += 250
    }
    span2.innerHTML = bs1tBonuses
    span3.innerHTML = salaryWithBonuses
    span4.innerHTML = salaryOT
    span5.innerHTML = totalYearlySalary
    span6.innerHTML = monthlyWithoutPB
    span7.innerHTML = monthlyWithPB
}